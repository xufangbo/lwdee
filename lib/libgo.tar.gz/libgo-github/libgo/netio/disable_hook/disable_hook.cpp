namespace co {
    void initHook() {}
}
