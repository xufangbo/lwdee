#pragma once

#define ENABLE_DEBUGGER 0

#define ENABLE_HOOK 1

// 使用旧版本的协程同步套件
#define USE_ROUTINE_SYNC 1
